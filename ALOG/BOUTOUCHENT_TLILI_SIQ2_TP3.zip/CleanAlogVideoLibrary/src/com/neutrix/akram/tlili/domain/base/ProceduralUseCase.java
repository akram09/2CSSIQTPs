package com.neutrix.akram.tlili.domain.base;

public abstract class ProceduralUseCase<R>{
    public abstract R execute();
}