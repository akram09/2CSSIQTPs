package com.neutrix.akram.tlili.domain.base;

public abstract class ProceduralVoidUseCase{
    public abstract void execute();
}
